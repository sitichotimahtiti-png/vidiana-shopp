# Backend

This folder is a placeholder for the Express backend. In the full project scaffold, the backend includes endpoints for products, auth, orders, and real-time chat via Socket.io.

For now you can use the frontend as static demo.