-- Seed products for Vidiana Shopp
INSERT INTO products (id, title, price, stock, image_url, description) VALUES (1, 'AQUA GALON 19L', 25000, 50, '/images/aqua-19l.jpg', 'Air mineral AQUA galon 19 liter - isi ulang dan segar.');
INSERT INTO products (id, title, price, stock, image_url, description) VALUES (2, 'VIT GALON 19L', 24000, 40, '/images/vit-19l.jpg', 'Air mineral VIT galon 19 liter - berkualitas.');
INSERT INTO products (id, title, price, stock, image_url, description) VALUES (3, 'LE MINERAL GALON 15L', 20000, 30, '/images/le-15l.jpg', 'Air LE Mineral galon 15 liter.');
INSERT INTO products (id, title, price, stock, image_url, description) VALUES (4, 'AIR ISI ULANG RO 19L', 18000, 100, '/images/ro-19l.jpg', 'Air isi ulang proses RO 19 liter.');
INSERT INTO products (id, title, price, stock, image_url, description) VALUES (5, 'Gas LPG 3Kg', 18000, 200, '/images/lpg-3kg.jpg', 'Tabung gas LPG 3kg untuk kebutuhan rumah tangga.');
