import React from 'react'
import products from './data_products.json'

export default function App(){
  return (
    <div style={{fontFamily:'Arial, sans-serif', padding:20, background:'#f7fbff', minHeight:'100vh'}}>
      <header style={{display:'flex', alignItems:'center', gap:12}}>
        <img src="/logo-vidiana.png" alt="Vidiana" style={{width:80,height:80,borderRadius:20}}/>
        <h1 style={{color:'#0A55A0'}}>VIDIANA SHOPP</h1>
      </header>
      <main style={{marginTop:20}}>
        <h2 style={{color:'#084a8a'}}>Produk Kami</h2>
        <div style={{display:'grid', gridTemplateColumns:'repeat(auto-fill, minmax(220px,1fr))', gap:16, marginTop:12}}>
          {products.map(p=>(
            <div key={p.id} style={{background:'#fff', padding:12, borderRadius:12, boxShadow:'0 2px 6px rgba(0,0,0,0.06)'}}>
              <div style={{height:140, background:'#e9f2ff', borderRadius:8, display:'flex', alignItems:'center', justifyContent:'center'}}>
                <span style={{color:'#0a55a0'}}>{p.title}</span>
              </div>
              <h3 style={{marginTop:8}}>{p.title}</h3>
              <p>Rp {p.price.toLocaleString()}</p>
              <button style={{background:'#0A55A0', color:'#fff', padding:'8px 12px', borderRadius:8, border:'none', cursor:'pointer'}}>Tambah ke Keranjang</button>
            </div>
          ))}
        </div>
      </main>
    </div>
  )
}
